# OpenDrawer matched-task evidence

This text-only archive contains OpenDrawer seeds 1-5 from September 11 and
October 9, 2026. The successes are 5/5 and 2/5 respectively. It is one task,
not the full Target50 evaluation and not a controlled model-version comparison.

| Metric | September | October |
| --- | ---: | ---: |
| Successes / episodes | 5/5 | 2/5 |
| Output tokens | 28,510 | 15,684 |
| Reasoning output tokens | 12,455 | 3,583 |
| Input + output tokens | 5,213,899 | 3,414,903 |

Output includes reasoning output, and input includes cached input. Do not add
these subsets again. See case_comparison.csv and the individual result records.

October uses GPT-6 Astra, high reasoning, eight concurrent episodes, RPent
commit 646e02635b3ec99c9ce050229477c1c80ee29899, and RLinf/RPent-memory
commit 38be61db66c10b97f276f0efc8a65235c2cf2d24 (robocasa-gpt6).
The historical source model field remains null. Code and memory presentation
differ between periods. This is not the leaderboard's low-reasoning setting.

## Redaction and source selection

Local absolute paths, credential fields, credential-like strings, email and
IP addresses have been redacted. Numerical token statistics, success outcomes,
seeds and configuration values are unchanged. Only the matching historical
JSON document is retained when a source file contains multiple attempts.
The 1-based document indices are recorded in source_selection.json.
Other tasks, videos and full memory snapshots are not included.

Source text-only tar SHA-256: ba4bde23d88847a0444bc608fefd6a50079e84821a23b0d63837b31fd6aab6a7
SHA256SUMS lists the sanitized archive contents, not the unredacted source.
